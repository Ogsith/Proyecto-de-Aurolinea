from PyQt5 import QtWidgets, uic
from Vista.VentanaPrincipal import VentanaPrincipal

qtCreatorFile = "UI/Login.ui"
Ui_MainWindow, QtBaseClass = uic.loadUiType(qtCreatorFile)

class Login(QtWidgets.QMainWindow):
    def __init__(self, parent = None):
        super(Login, self).__init__(parent)
        uic.loadUi("UI/Login.ui", self)
        self.btn_iniciar.clicked.connect(self.IniciarSesion)
        self.show()

    def IniciarSesion(self):
        usuario = self.txt_usuario.text()
        contraseña = self.txt_password.text()

        if usuario == "admin" and contraseña == "admin":
            self.close()
            v_principal = VentanaPrincipal(self)
            v_principal.show()

