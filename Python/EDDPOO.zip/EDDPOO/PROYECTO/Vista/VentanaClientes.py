from PyQt5 import QtWidgets, uic
from Controlador.ArregloClientes import *

aCli = ArregloClientes()

class VentanaClientes(QtWidgets.QMainWindow):
    def __init__(self, parent = None):
        super(VentanaClientes, self).__init__(parent)
        uic.loadUi("UI/VentanaClientes.ui", self)

        self.btn_Registrar.clicked.connect(self.registrar)
        self.btn_Modificar.clicked.connect(self.modificar)
        self.btn_Consultar.clicked.connect(self.consultar)
        self.btn_Eliminar.clicked.connect(self.eliminar)
        self.btn_Listar.clicked.connect(self.listar)
        self.btn_Grabar.clicked.connect(self.grabar)
    
    def obtenerDniCliente(self):
        return self.txt_Dni.text()
    def obtenerNombres(self):
        return self.txt_Nombres.text()
    def obtenerApellidoPaterno(self):
        return self.txt_ApellidoPaterno.text()
    def obtenerApellidoMaterno(self):
        return self.txt_ApellidoMaterno.text()
    def obtenerDireccion(self):
        return self.txt_Direccion.text()
    def obtenerTelefono(self):
        return self.txt_Telefono.text()
    
    def LimpiarTabla(self):
        self.tbl_Clientes.clearContents()
        self.tbl_Clientes.setRowCount(0)
    
    def validar(self):
        if self.txt_Dni.text() == "":
            self.txt_Dni.setFocus()
            return "Dni del cliente...!!!"
        elif self.txt_Nombres.text() == "":
            self.txt_Nombres.setFocus()
            return "Nombre del cliente...!!!"
        elif self.txt_ApellidoPaterno.text() == "":
            self.txt_ApellidoPaterno.setFocus()
            return "Apellido paterno del cliente...!!!"
        elif self.txt_ApellidoMaterno.text() == "":
            self.txt_ApellidoMaterno.setFocus()
            return "Apellido materno del cliente...!!!"
        elif self.txt_Direccion.text() == "":
            self.txt_Direccion.setFocus()
            return "Dirección del cliente...!!!"
        elif self.txt_Telefono.text() == "":
            self.txt_Telefono.setFocus()
            return "Teléfono del cliente...!!!"
        else:
            return ""

    def listar(self):
        self.tbl_Clientes.setRowCount(aCli.tamañoArregloCliente())
        self.tbl_Clientes.setColumnCount(6)
        for i in range(aCli.tamañoArregloCliente()):
            self.tbl_Clientes.setItem(i, 0,QtWidgets.QTableWidgetItem(aCli.devolverCliente(i).getDniCliente()))
            self.tbl_Clientes.setItem(i, 1, QtWidgets.QTableWidgetItem(aCli.devolverCliente(i).getNombresCliente()))
            self.tbl_Clientes.setItem(i, 2, QtWidgets.QTableWidgetItem(aCli.devolverCliente(i).getApellidoPaternoCliente()))
            self.tbl_Clientes.setItem(i, 3, QtWidgets.QTableWidgetItem(aCli.devolverCliente(i).getApellidoMaternoCliente()))
            self.tbl_Clientes.setItem(i, 4, QtWidgets.QTableWidgetItem(aCli.devolverCliente(i).getDireccionCliente()))
            self.tbl_Clientes.setItem(i, 5, QtWidgets.QTableWidgetItem(aCli.devolverCliente(i).getTelefonoCliente()))
    
    def limpiarControles(self):
        self.txt_Dni.clear()
        self.txt_Nombres.clear()
        self.txt_ApellidoPaterno.clear()
        self.txt_ApellidoMaterno.clear()
        self.txt_Direccion.clear()
        self.txt_Telefono.clear()

    def registrar(self):
        if self.validar() == "":
            objCli = Cliente( self.obtenerDniCliente(), self.obtenerNombres(), self.obtenerApellidoPaterno(), self.obtenerApellidoMaterno(), self.obtenerDireccion(), self.obtenerTelefono())
            Dni = self.obtenerDniCliente()
            if aCli.buscarCliente(Dni) == -1:
                aCli.adicionaCliente(objCli)
                self.limpiarControles()
                self.listar()
            else:
                QtWidgets.QMessageBox.information(self, "Registrar cliente", "El DNI ingresado ya existe...!!!", QtWidgets.QMessageBox.Ok)
        else:
            QtWidgets.QMessageBox.information(self, "Registrar Cliente", "Error en "+ self.validar(), QtWidgets.QMessageBox.Ok)
    
    def consultar(self):
        self.LimpiarTabla()
        if aCli.tamañoArregloCliente() == 0:
            QtWidgets.QMessageBox.information(self,"Consultar cliente", "No existen cliente a consultar...!!!", QtWidgets.QMessageBox.Ok)
        else:
            Dni, _=QtWidgets.QInputDialog.getText(self, "Consultar cliente", "Ingrese el DNI a conusltar...!!!")
            pos = aCli.buscarCliente(Dni)
            if pos == -1:
                QtWidgets.QMessageBox.information(self,"Consultar cliente", "El DNI ingresado no existe...!!!", QtWidgets.QMessageBox.Ok)
            else:
                 self.tbl_Clientes.setRowCount(1)
                 self.tbl_Clientes.setItem(0, 0, QtWidgets.QTableWidgetItem(aCli.devolverCliente(pos).getDniCliente()))
                 self.tbl_Clientes.setItem(0, 1, QtWidgets.QTableWidgetItem(aCli.devolverCliente(pos).getNombres()))
                 self.tbl_Clientes.setItem(0, 2, QtWidgets.QTableWidgetItem(aCli.devolverCliente(pos).getApellidoPaternoCliente()))
                 self.tbl_Clientes.setItem(0, 3, QtWidgets.QTableWidgetItem(aCli.devolverCliente(pos).getApellidoMaternoCliente()))
                 self.tbl_Clientes.setItem(0, 4, QtWidgets.QTableWidgetItem(aCli.devolverCliente(pos).getDireccionCliente()))
                 self.tbl_Clientes.setItem(0, 5, QtWidgets.QTableWidgetItem(aCli.devolverCliente(pos).getTelefonoCliente()))

    def eliminar(self):
        if aCli.tamañoArregloCliente() == 0:
            QtWidgets.QMessageBox.information(self, "Eliminar cliente", "No existen clientes a eliminar...!!!", QtWidgets.QMessageBox.Ok)
        else:
            fila = self.tbl_Clientes.selectedItems()
            if fila:
                indiceFila = fila[0].row()
                Dni = self.tbl_Clientes.item(indiceFila, 0).text()
                pos = aCli.buscarCliente(Dni)
                aCli.eliminarCliente(pos)
                self.LimpiarTabla
                self.listar()
            else:
                QtWidgets.QMessageBox.information(self, "Eliminar cliente", "Debe seleccionar una fila...!!!", QtWidgets.QMessageBox.Ok)

    def modificar(self):
        if aCli.tamañoArregloCliente() == 0:
            QtWidgets.QMessageBox.information(self, "Modificar cliente", "No existen clientes a modificar...!!!", QtWidgets.QMessageBox.Ok)
        else:
            Dni, _ = QtWidgets.QInputDialog.getText(self, "Modificar cliente", "Ingrese el DNI a modificar...!!!")
            pos = aCli.buscarCliente(Dni)
            if pos != -1:
                objCliente = aCli.devolverCliente(pos)
                self.btn_Modificar.setVisible(False)
                self.btn_Grabar.setVisible(True)
                self.txt_Dni.setText(objCliente.getDniCliente())
                self.txt_Dni.setVisible(False)
                self.lbl_Dni.setVisible(False)
                self.txt_Nombres.setText(objCliente.getNombresCliente())
                self.txt_ApellidoPaterno.setText(objCliente.getApellidoPaternoCliente())
                self.txt_ApellidoMaterno.setText(objCliente.getApellidoMaternoCliente())
                self.txt_Direccion.setText(objCliente.getDireccionCliente())
                self.txt_Telefono.setText(objCliente.getTelefonoCliente())
        
    def grabar(self):
        try:
            pos = aCli.buscarCliente(self.obtenerDniCliente())
            objCliente = aCli.devolverCliente(pos)
            objCliente.setDniCliente(self.obtenerDniCliente())
            objCliente.setNombreCliente(self.obtenerNombres())
            objCliente.setApellidoPaternoCliente(self.obtenerApellidoPaterno())
            objCliente.setApellidoMaternoCliente(self.obtenerApellidoMaterno())
            objCliente.setDireccionCliente(self.obtenerDireccion())
            objCliente.setTelefonoCliente(self.obtenerTelefono())
            self.btn_Modificar.setVisible(True)
            self.btn_Grabar.setVisible(False)
            self.LimpiarTabla()
            self.limpiarControles()
            self.listar()
            self.txt_Dni.setVisible(True)
            self.lbl_Dni.setVisible(True)        
        except:
            QtWidgets.QMessageBox.information(self, "Modificar cliente", "Error al modificar cliente...!!!", QtWidgets.QMessageBox.Ok)