from PyQt5 import QtWidgets, uic
from Vista.VentanaProductos import VentanaProductos
from Vista.VentanaClientes import VentanaClientes
from Vista.VentanaVentas import VentanaVentas

class VentanaPrincipal(QtWidgets.QMainWindow):
    def __init__(self, parent = None):
        super(VentanaPrincipal, self).__init__(parent)
        uic.loadUi("UI/VentanaPrincipal.ui", self)

        self.btn_Productos.clicked.connect(self.Abrir_Ventana_Producto)
        self.btn_Clientes.clicked.connect(self.Abrir_Ventana_Clientes)
        self.btn_Vender.clicked.connect(self.Abrir_Ventana_Ventas)
        self.btn_Salir.clicked.connect(self.Icono_Salir)

    def Abrir_Ventana_Producto(self):
        v_productos = VentanaProductos(self)
        v_productos.show()
    
    def Abrir_Ventana_Clientes(self):
        v_clientes = VentanaClientes(self)
        v_clientes.show()

    def Abrir_Ventana_Ventas(self):
        v_Ventas = VentanaVentas(self)
        v_Ventas.show()

    def Icono_Salir(self):
        self.close()