from PyQt5 import QtWidgets, uic
from Controlador.ArregloProductos import *

aPro = ArregloProductos()

class VentanaProductos(QtWidgets.QMainWindow):
    def __init__(self, parent = None):
        super(VentanaProductos, self).__init__(parent)
        uic.loadUi("UI/VentanaProductos.ui", self)

        self.btn_Registrar.clicked.connect(self.registrar)
        self.btn_Modificar.clicked.connect(self.modificar)
        self.btn_Consultar.clicked.connect(self.consultar)
        self.btn_Eliminar.clicked.connect(self.eliminar)
        self.btn_Listar.clicked.connect(self.listar)
        self.btn_Grabar.clicked.connect(self.grabar)

        self.listar()

    def obtenerCodigo(self):
        return self.txt_Codigo.text()
    def obtenerNombre(self):
        return self.txt_Nombre.text()
    def obtenerDescripcion(self):
        return self.txt_Descripcion.text()
    def obtenerStockMinimo(self):
        return self.txt_StockMinimo.text()
    def obtenerStockActual(self):
        return self.txt_StockActual.text()
    def obtenerPrecioCosto(self):
        return self.txt_PrecioCosto.text()
    def obtenerPrecioVenta(self):
        return self.txt_PrecioVenta.text()
    def obtenerProveedor(self):
        return self.cbo_Proveedor.currentText()
    def obtenerAlmacen(self):
        return self.cbo_Almacen.currentText()

    def LimpiarTabla(self):
        self.tbl_Productos.clearContents()
        self.tbl_Productos.setRowCount(0)

    def validar(self):
        if self.txt_Codigo.text() == "":
            self.txt_Codigo.setFocus()
            return "Codigo del producto...!!!"
        elif self.txt_Nombre.text() == "":
            self.txt_Nombre.setFocus()
            return "Nombre del producto...!!!"
        elif self.txt_Descripcion.text() == "":
            self.txt_Descripcion.setFocus()
            return "Descripción del producto...!!!"
        elif self.txt_StockMinimo.text() == "":
            self.txt_StockMinimo.setFocus()
            return "Stock mínimo del producto...!!!"
        elif self.txt_StockActual.text() == "":
            self.txt_StockActual.setFocus()
            return "Stock actual del producto...!!!"
        elif self.txt_PrecioCosto.text() == "":
            self.txt_PrecioCosto.setFocus()
            return "Precio costo del producto...!!!"
        elif self.txt_PrecioVenta.text() == "":
            self.txt_PrecioVenta.setFocus()
            return "Precio venta del producto...!!!"
        elif self.cbo_Proveedor.currentText() == "Seleccionar Proveedor":
            self.cbo_Proveedor.setCurrentIndex(0)
            return "Proveedor del producto...!!!"
        elif self.cbo_Almacen.currentText() == "Seleccionar Almacén":
            self.cbo_Almacen.setCurrentIndex(0)
            return "Almacén del producto...!!!"
        else:
            return ""
        
    def listar(self):
        self.tbl_Productos.setRowCount(aPro.tamañoArregloProducto())
        self.tbl_Productos.setColumnCount(9)
        for i in range(aPro.tamañoArregloProducto()):
            self.tbl_Productos.setItem(i, 0,QtWidgets.QTableWidgetItem(aPro.devolverProducto(i).getCodigo()))
            self.tbl_Productos.setItem(i, 1, QtWidgets.QTableWidgetItem(aPro.devolverProducto(i).getNombre()))
            self.tbl_Productos.setItem(i, 2, QtWidgets.QTableWidgetItem(aPro.devolverProducto(i).getDescripcion()))
            self.tbl_Productos.setItem(i, 3, QtWidgets.QTableWidgetItem(aPro.devolverProducto(i).getStockMinimo()))
            self.tbl_Productos.setItem(i, 4, QtWidgets.QTableWidgetItem(aPro.devolverProducto(i).getStockActual()))
            self.tbl_Productos.setItem(i, 5, QtWidgets.QTableWidgetItem(aPro.devolverProducto(i).getPrecioCosto()))
            self.tbl_Productos.setItem(i, 6, QtWidgets.QTableWidgetItem(aPro.devolverProducto(i).getPrecioVenta()))
            self.tbl_Productos.setItem(i, 7, QtWidgets.QTableWidgetItem(aPro.devolverProducto(i).getProveedor()))
            self.tbl_Productos.setItem(i, 8, QtWidgets.QTableWidgetItem(aPro.devolverProducto(i).getAlmacen()))
        
    def limpiarControles(self):
        self.txt_Codigo.clear()
        self.txt_Nombre.clear()
        self.txt_Descripcion.clear()
        self.txt_StockMinimo.clear()
        self.txt_StockActual.clear()
        self.txt_PrecioCosto.clear()
        self.txt_PrecioVenta.clear()
        self.cbo_Proveedor.setCurrentIndex(0)
        self.cbo_Almacen.setCurrentIndex(0)

    def registrar(self):
        if self.validar() == "":
            objPro = Producto( self.obtenerCodigo(), self.obtenerNombre(), self.obtenerDescripcion(), self.obtenerStockMinimo(), self.obtenerStockActual(), self.obtenerPrecioCosto(), self.obtenerPrecioVenta(), self.obtenerProveedor(), self.obtenerAlmacen())
            codigo = self.obtenerCodigo()
            if aPro.buscarProducto(codigo) == -1:
                aPro.adicionaProducto(objPro)
                self.limpiarControles()
                self.listar()
            else:
                QtWidgets.QMessageBox.information(self, "Registrar producto", "El código ingresado ya existe...!!!", QtWidgets.QMessageBox.Ok)
        else:
            QtWidgets.QMessageBox.information(self, "Registrar producto", "Error en "+ self.validar(), QtWidgets.QMessageBox.Ok)

    def consultar(self):
        self.LimpiarTabla()
        if aPro.tamañoArregloProducto() == 0:
            QtWidgets.QMessageBox.information(self,"Consultar producto", "No existen productos a consultar...!!!", QtWidgets.QMessageBox.Ok)
        else:
            codigo, _=QtWidgets.QInputDialog.getText(self, "Consultar prodcutos", "Ingrese el código a conusltar...!!!")
            pos = aPro.buscarProducto(codigo)
            if pos == -1:
                QtWidgets.QMessageBox.information(self,"Consultar producto", "El código ingresado no existe...!!!", QtWidgets.QMessageBox.Ok)
            else:
                 self.tbl_Productos.setRowCount(1)
                 self.tbl_Productos.setItem(0, 0, QtWidgets.QTableWidgetItem(aPro.devolverProducto(pos).getCodigo()))
                 self.tbl_Productos.setItem(0, 1, QtWidgets.QTableWidgetItem(aPro.devolverProducto(pos).getNombre()))
                 self.tbl_Productos.setItem(0, 2, QtWidgets.QTableWidgetItem(aPro.devolverProducto(pos).getDescripcion()))
                 self.tbl_Productos.setItem(0, 3, QtWidgets.QTableWidgetItem(aPro.devolverProducto(pos).getStockMinimo()))
                 self.tbl_Productos.setItem(0, 4, QtWidgets.QTableWidgetItem(aPro.devolverProducto(pos).getStockActual()))
                 self.tbl_Productos.setItem(0, 5, QtWidgets.QTableWidgetItem(aPro.devolverProducto(pos).getPrecioCosto()))
                 self.tbl_Productos.setItem(0, 6, QtWidgets.QTableWidgetItem(aPro.devolverProducto(pos).getPrecioVenta()))
                 self.tbl_Productos.setItem(0, 7, QtWidgets.QTableWidgetItem(aPro.devolverProducto(pos).getProveedor()))
                 self.tbl_Productos.setItem(0, 8, QtWidgets.QTableWidgetItem(aPro.devolverProducto(pos).getAlmacen()))
    
    def eliminar(self):
        if aPro.tamañoArregloProducto() == 0:
            QtWidgets.QMessageBox.information(self, "Eliminar producto", "No existen productos a eliminar...!!!", QtWidgets.QMessageBox.Ok)
        else:
            fila = self.tbl_Productos.selectedItems()
            if fila:
                indiceFila = fila[0].row()
                codigo = self.tbl_Productos.item(indiceFila, 0).text()
                pos = aPro.buscarProducto(codigo)
                aPro.eliminarProducto(pos)
                self.LimpiarTabla
                self.listar()
            else:
                QtWidgets.QMessageBox.information(self, "Eliminar producto", "Debe seleccionar una fila...!!!", QtWidgets.QMessageBox.Ok)

    def modificar(self):
        if aPro.tamañoArregloProducto() == 0:
            QtWidgets.QMessageBox.information(self, "Modificar producto", "No existen productos a modificar...!!!", QtWidgets.QMessageBox.Ok)
        else:
            codigo, _ = QtWidgets.QInputDialog.getText(self, "Modificar producto", "Ingrese el código a modificar...!!!")
            pos = aPro.buscarProducto(codigo)
            if pos != -1:
                objProducto = aPro.devolverProducto(pos)
                self.btn_Modificar.setVisible(False)
                self.btn_Grabar.setVisible(True)
                self.txt_Codigo.setText(objProducto.getCodigo())
                self.txt_Codigo.setVisible(False)
                self.lbl_Codigo.setVisible(False)
                self.txt_Nombre.setText(objProducto.getNombre())
                self.txt_Descripcion.setText(objProducto.getDescripcion())
                self.txt_StockMinimo.setText(objProducto.getStockMinimo())
                self.txt_StockActual.setText(objProducto.getStockActual())
                self.txt_PrecioCosto.setText(objProducto.getPrecioCosto())
                self.txt_PrecioVenta.setText(objProducto.getPrecioVenta())
                self.cbo_Proveedor.setCurrentText(objProducto.getProveedor())
                self.cbo_Almacen.setCurrentText(objProducto.getAlmacen())

    def grabar(self):
        try:
            pos = aPro.buscarProducto(self.obtenerCodigo())
            objProducto = aPro.devolverProducto(pos)
            objProducto.setNombre(self.obtenerNombre())
            objProducto.setDescripcion(self.obtenerDescripcion())
            objProducto.setStockMinimo(self.obtenerStockMinimo())
            objProducto.setStockActual(self.obtenerStockActual())
            objProducto.setPrecioCosto(self.obtenerPrecioCosto())
            objProducto.setPrecioVenta(self.obtenerPrecioVenta())
            objProducto.setProveedor(self.obtenerProveedor())
            objProducto.setAlmacen(self.obtenerAlmacen())
            self.btn_Modificar.setVisible(True)
            self.btn_Grabar.setVisible(False)
            self.LimpiarTabla()
            self.limpiarControles()
            self.listar()
            self.txt_Codigo.setVisible(True)
            self.lbl_Codigo.setVisible(True)        
        except:
            QtWidgets.QMessageBox.information(self, "Modificar producto", "Error al modificar producto...!!!", QtWidgets.QMessageBox.Ok)