from PyQt5 import QtWidgets, uic
from Controlador.ArregloProductos import *
from Controlador.ArregloClientes import *
from Vista.VentanaProductos import *
from Vista.VentanaClientes import *
from datetime import date

lista = []

class VentanaVentas(QtWidgets.QMainWindow):
    def __init__(self, parent = None):
        super(VentanaVentas, self).__init__(parent)
        uic.loadUi("UI/VentanaVentas.ui", self)

        self.btn_BuscarCliente.clicked.connect(self.buscarCliente)
        self.btn_BuscarProducto.clicked.connect(self.buscarProducto)
        self.btn_Agregar.clicked.connect(self.agregar)
        self.btn_Cerrar.clicked.connect(self.cerrar)
        self.calcularFecha()
        self.item = 0

    def buscarCliente(self):
        codigoCliente = self.txt_CodigoCliente.text()
        if self.txt_CodigoCliente.text() == "":
            QtWidgets.QMessageBox.information(self, "Código Cliente", "Debe ingresar el código del cliente...!!!", QtWidgets.QMessageBox.Ok)    
        else:
            pos = aCli.buscarCliente(codigoCliente)
            objCliente = aCli.devolverCliente(pos)
            if pos == -1:
                QtWidgets.QMessageBox.information(self, "Código Cliente", "Cliente no registrado...!!!", QtWidgets.QMessageBox.Ok)    
            else:
                self.txt_Nombres.setText(objCliente.getNombresCliente()+" "+objCliente. getApellidoPaternoCliente()+" "+objCliente. getApellidoMaternoCliente())    

    def buscarProducto(self):
        codigoProducto = self.txt_CodigoProducto.text()
        if self.txt_CodigoProducto.text() == "":
            QtWidgets.QMessageBox.information(self, "Código Producto", "Debe ingresar el código del producto...!!!", QtWidgets.QMessageBox.Ok)    
        else:
            pos = aPro.buscarProducto(codigoProducto)
            objProducto = aPro.devolverProducto(pos)
            if pos == -1:
                QtWidgets.QMessageBox.information(self, "Código Producto", "Producto no registrado...!!!", QtWidgets.QMessageBox.Ok)    
            else:
                self.txt_Descripcion.setText(objProducto.getDescripcion())
                self.txt_Stock.setText(objProducto.getStockActual())
                self.txt_Precio.setText(objProducto.getPrecioVenta())

    def obtenerNumeroDocumento(self):
        return self.txt_NumeroDocumento.txt()
    
    def obtenerCodigo(self):
        return self.txt_CodigoProducto.text()
    
    def obtenerDescripcion(self):
        return self.txt_Descripcion.text()
    
    def obtenerPrecio(self):
        return float(self.txt_Precio.text())
    
    def obtenerCantidad(self):
        return int(self.txt_Cantidad.text())

    def obtenerItem(self):
        self.item = self.item + 1
        return  self.item
    
    def obtenerFecha(self):
        return self.txt_Fecha.text()

    def calcularFecha(self):
        self.fecha = date.today()
        dia = self.fecha.day
        mes = self.fecha.month
        año = self.fecha.year
        self.txt_Fecha.setText(str(dia)+"/"+str(mes)+"/"+str(año))

    def limpiarControles(self):
        self.txt_CodigoProducto.clear()
        self.txt_Descripcion.clear()
        self.txt_Stock.clear()
        self.txt_Precio.clear()
        self.txt_Cantidad.clear()

    def mostrarDetalle(self):
        self.tbl_Detalle.setRowCount(len(lista))
        self.tbl_Detalle.setColumnCount(6)
        for i in range(len(lista)):
            self.tbl_Detalle.setItem(i, 0, QtWidgets.QTableWidgetItem(str(lista[i][0])))
            self.tbl_Detalle.setItem(i, 1, QtWidgets.QTableWidgetItem(str(lista[i][1])))
            self.tbl_Detalle.setItem(i, 2, QtWidgets.QTableWidgetItem(str(lista[i][2])))
            self.tbl_Detalle.setItem(i, 3, QtWidgets.QTableWidgetItem(str(lista[i][3])))
            self.tbl_Detalle.setItem(i, 4, QtWidgets.QTableWidgetItem(str(lista[i][4])))
            self.tbl_Detalle.setItem(i, 5, QtWidgets.QTableWidgetItem(str(lista[i][5])))
        self.limpiarControles()
    
    def calcularPago(self):
        self.subtotal_pagar = 0
        for i in range(len(lista)):
            self.subTotal = lista[i][5]
            self.subtotal_pagar = self.subtotal_pagar + float(self.subTotal)
            self.igv = 0.18 * self.subtotal_pagar
            self.total_pagar = self.subtotal_pagar + self.igv
        self.txt_SubTotal.setText("S/. " + str(round(self.subtotal_pagar, 2)))
        self.txt_Igv.setText("S/. " + str(round(self.igv, 2)))
        self.txt_TotalPagar.setText("S/. " + str(round(self.total_pagar, 2)))

    def agregar(self):
        try:
            if int(self.txt_Cantidad.text()) > int(self.txt_Stock.text()):
                QtWidgets.QMessageBox.information(self, "Venta", "No se puede vender esa cantidad...!!!", QtWidgets.QMessageBox.Ok)
            elif int(self.txt_Cantidad.text()) <= 0:
                QtWidgets.QMessageBox.information(self, "Venta", "La cantidad ingresada es incorrecta...!!!", QtWidgets.QMessageBox.Ok)
            else:
                lista.append((self.obtenerItem(), self.obtenerCodigo(), self.obtenerDescripcion(), self.obtenerPrecio(), self.obtenerCantidad(), self.obtenerPrecio() * self.obtenerCantidad()))
                self.mostrarDetalle()
                self.calcularPago()
        except:
            QtWidgets.QMessageBox.information(self, "Agregar Detalle", "No se han completado los detalles del producto...!!!", QtWidgets.QMessageBox.Ok)
            self.item = self.item - 1 
    
    def cerrar(self):
        self.close()
